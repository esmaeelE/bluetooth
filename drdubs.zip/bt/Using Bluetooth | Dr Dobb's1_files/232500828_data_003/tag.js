(function(w, d, s) {
  try {
    d = w.top.document || d; w = w.top.document ? w.top : w;
  } catch (e) {}
  var ttag = function() {
    w.teads.page(11510).placement(21880, {slider: {allow_corner_position: false, allow_top_position: false}, "css":"padding-bottom: 8px;","format":"inread","slot":{"selector":".story p","minimum":5}}).serve();
  };
  if (w.teads && w.teads.page) { ttag(); }
  else if (!w.teadsscript) {
    s.src = 'https://a.teads.tv/media/format/v3/teads-format.min.js';
    s.async = true; s.onload = ttag; w.teadsscript = d.getElementsByTagName('head')[0].appendChild(s);
  }
})(window, document, document.createElement('script'));