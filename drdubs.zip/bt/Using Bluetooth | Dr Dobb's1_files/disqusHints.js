$(document).ready(function(){
	$(".htmlTags").colorbox({width:"620px",height:"600px",inline:true,href:"#inlineModal"});//end .htmlTags
	$(".avatarUpload").colorbox({width:"450px", height:"550px", iframe:true});
	$(".hideHint").click(function(){
		$("#disuqsHints").slideUp('slow');
		$('#disuqsHints').load('http://'+brainyardDomain+'/thebrainyard/commenting/hidehints');
	});
});//end doc ready