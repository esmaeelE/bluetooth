
#include <bluetooth/bluetooth.h>
#include <bluetooth/rfcomm.h>

#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <bluetooth/sdp.h>
#include <bluetooth/sdp_lib.h>

#include <bluetooth/sco.h>

#include <sys/socket.h>

#include <unistd.h>
